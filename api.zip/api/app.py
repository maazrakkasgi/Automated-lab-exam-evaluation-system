import os
from flask import Flask, request, jsonify
from models import Exam, db, User, Student, Program
from competest import competest

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
db.init_app(app)
with app.app_context():
     db.create_all()

@app.route('/auth', methods=['POST'])
def authenticate_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    user_type = data.get('userType')
    print(user_type)

    if not username or not password or not user_type:
        return jsonify({'message': 'Username, password, and userType are required'}), 400

    user = User.query.filter_by(username=username, user_type=user_type).first()
    if user and user.password == password:
        return jsonify({'userId': user.user_id}), 200
    else:
        return jsonify({'message': 'Invalid username or password'}), 401

@app.route('/students', methods=['GET'])
def get_students():
    semester = request.args.get('semester')
    if semester:
        filtered_students = Student.query.filter_by(semester=semester).all()
        return jsonify([student.serialize() for student in filtered_students])
    return jsonify([student.serialize() for student in Student.query.all()])

@app.route('/get_exam', methods=['GET'])
def get_exams():
    usn_id = request.args.get('usn_id')
    print(usn_id)
    student_info = Student.query.filter_by(id=usn_id).first()
    exams = Exam.query.filter_by(semester=student_info.semester).first()

    return jsonify(exams.serialize())

@app.route('/list_exams', methods=['GET'])
def list_exams():
    exams = Exam.query.all()
    return jsonify([exam.serialize() for exam in exams])

@app.route('/students', methods=['POST'])
def add_student():
    data = request.get_json()
    name = data.get('name')
    dob = data.get('dob')
    usn = data.get('usn')
    semester = data.get('semester')

    if not name or not dob or not usn or not semester:
        return jsonify({'message': 'Name, dob, usn, and semester are required'}), 400

    new_student = Student(name=name, dob=dob, usn=usn, semester=semester)
    db.session.add(new_student)
    db.session.commit()

    # Set default password as DOB
    new_user = User(username=new_student.usn, password=dob, user_type='student', user_id=new_student.id)
    db.session.add(new_user)
    db.session.commit()

    return jsonify(new_student.serialize()), 201

@app.route('/submit_code', methods=['POST'])
def submit_code():
    data = request.get_json()
    text = data.get('code')
    programming_language = data.get('language')
    usn = data.get('usn')
    program_no = data.get('program_id')
    subject_id = data.get("subject_id")

    file_name = f"{usn}_text.program"

    with open(file_name, 'w') as f:
        f.write(text)

    test_cases = Program.query.filter_by(program_no=program_no, subject_id= subject_id).first()
    test_cases = test_cases.test_cases.replace('\r\n','\r')
    test_case_name = f"{usn}_text.txt"
    with open(test_case_name, 'w') as test_case_write:
        test_case_write.write(test_cases)

    output = competest.main(programming_language, file_name, None)

    os.remove(file_name)  # Remove the temporary file
    os.remove(test_case_name)

    return jsonify(output)

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
