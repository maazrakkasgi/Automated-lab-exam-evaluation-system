from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    dob = db.Column(db.String(10), nullable=False)
    usn = db.Column(db.String(10), nullable=False, unique=True)
    semester = db.Column(db.String(10), nullable=False)

    def serialize(self):
        return {
            'id': self.id,
            'name': self.name,
            'dob': self.dob,
            'usn': self.usn,
            'semester': self.semester
        }

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    user_type = db.Column(db.String(20), nullable=False)
    user_id = db.Column(db.String(30), nullable=False)

class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(20), nullable=False)
    scheme = db.Column(db.String(50), nullable=False)

    def serialize(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
            'scheme': self.scheme
        }

class Program(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)
    program_no = db.Column(db.String(20), nullable=False)
    program_info = db.Column(db.String(200), nullable=False)
    test_cases = db.Column(db.Text, nullable=False)

class Exam(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    semester = db.Column(db.String(10), nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)
    subject = db.relationship('Subject', backref=db.backref('exams', lazy=True))

    def serialize(self):
        return {
            'id': self.id,
            'semester': self.semester,
            'subject_id' : self.subject_id,
            'subject': self.subject.serialize() if self.subject else None
        }

class Grades(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usn = db.Column(db.String(20), nullable=False)
    grades = db.Column(db.String(20), nullable=False)
    test_cases_passed =  db.Column(db.Integer, nullable=False)